﻿using System;
using System.Collections.Generic;
namespace WhileLoop5 {
    internal class WhileLoop5 {
        // initilise global variables
        public static int[] lotto_nos = new int[5]; // array of 5 eleemnts
        public static bool status = false; // check if nos if 5 nos entered
        public static int index_no = 0; // track index no count of array
        public static int a_number = 0; // read user input
        static void Main(string[] args) {
            Console.WriteLine("Enter 5 Lotto Nos:");
            GetUserNos(lotto_nos);
            PrintArrayData(lotto_nos);
            PressAnyKey();
        }
        public static void GetUserNos(int[] lotto_nos) {
            while (!status) // status false do, when true then exit
            {
                // Condition to check if number enter is between 1 and 35
                while ((a_number < 1) || (a_number > 35))
                {
                    Console.Write("Enter number " + (index_no +1) + " value: ");
                    // read user input and convert to int
                    a_number = Convert.ToInt32(Console.ReadLine());
                }
                // assign user input not to array * tack index no
                lotto_nos[index_no] = a_number;
                index_no++; // increment index number ass you assign no to array
                a_number = 0; // reset number to 0 out side of input range
                if (index_no == 5) { status = true; } // exit to cound 5 elements
            }
        }
        public static void PrintArrayData(int[] lotto_nos)
        // pass lotto nos as an array to function and print user lotto nos
        {
            Console.Write("Lotto No: [");
            for(int i = 0; i < lotto_nos.Length; i++)
            {
                Console.Write(lotto_nos[i] + ",");
            }
            Console.Write("\b]");
        }
        public static void PressAnyKey()
        // Function to Prompt user to press any key ..
        // pause app on screen
        {
            Console.WriteLine();
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
    }
}
