﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
namespace ExpAppendText2 {
    class ExpAppendText2 {
        static void Main(string[] args)
        {
            string file_name = @"LottoNos.txt";
            string path = @"C:\Users\Demo1\Desktop\Apps\ExpAppendText2\bin\Debug\";
            string file = path + file_name;
            //string temp = "2 23/03/2023 [3,4,5,6,7] [11]";
            string temp = "3 24/03/2023 [4,5,6,7,8] [3]";
            try
            {
                using (StreamWriter sw = File.AppendText(file))
                {                    
                    //if(File.Exists(file_name)) { sw.Write("\n"); }
                    sw.WriteLine(temp);
                }
            }
            catch (Exception ex) { Console.WriteLine("Error: " + ex.Message);  }
            Console.Write("Press any key to contine...");
            Console.Read();
        }
    }
}
