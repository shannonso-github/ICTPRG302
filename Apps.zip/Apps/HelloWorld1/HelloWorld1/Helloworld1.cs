﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld1
{
    internal class Helloworld1
    {
        static void Main(string[] args)
        {
            Console.Write("Hello World\n");
            Console.Write("\nPress Any Key to continue...");
            Console.ReadLine();
        }
    }
}
