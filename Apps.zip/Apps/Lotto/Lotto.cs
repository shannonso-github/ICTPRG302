﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Lotto
{
    class Lotto
    {
        public static bool status = false;
        static void Main(string[] args)
        {
            //DisplayMenu();
            //ReadFile();
            ProcessMenuItem();
            Pause();
        }
        public static void DisplayMenu()
        {
            //int menu_item = -1;
            Console.WriteLine("/************************************");
            Console.WriteLine("*\t\tLotto");
            Console.WriteLine("*************************************");
            Console.WriteLine("1. Play lotto");
            Console.WriteLine("2. View Previous winning no");
            Console.WriteLine("3. View Players Numbers selected previously");
            Console.WriteLine("4. Exit");
            Console.Write("Enter Menu Selection [1-4]: ");
            //Console.ReadLine();
        }
        public static void ProcessMenuItem()
        {
            while(!status)
            {
                DisplayMenu();
                ReadMenuItem();
            }
        }
        public static void ReadMenuItem()
        {
            //int menu_item = -1;
            //menu_item = Convert.ToInt32(Console.ReadLine());
            switch (Console.ReadLine())
            {
                case "1":
                    Console.WriteLine("Play Lotto()");
                //    Console.Read();
                    break;
                case "2":
                    ViewPreviousWinningNumebrs();
                    break;
                case "3":
                    break;
                case "4":
                    status = true;
                    break;
                default:
                    Console.Clear();
                    break;
            }
        }

        public static void ViewPreviousWinningNumebrs()
        {
            Console.WriteLine("2. ViewPreviousWinningNumebrs()");
            //Console.Read();
        }

        public static void ReadFile()
        {
            Console.WriteLine("Reading File..");
        }
        public static void Pause()
        {
            Console.WriteLine("Press any key to continue... ");
            Console.ReadLine();
        }
    }    
}
