﻿using System;
using System.Collections.Generic; // List<string>
using System.IO;   // Stream, File
using System.Linq;
using System.Text; // Encoding.UTF
namespace ExpReadFile {
    class ExpReadFile {
        static void Main(string[] args) // C:\Users\Demo1\Desktop\Apps\ExpReadFile\bin\Debug
        {
            string file_name = "LottoNos.txt";
            string path = @"C:\Users\Demo1\Desktop\Apps\ExpReadFile\bin\Debug\";
            FileStream ref_data_soure = new FileStream(path + file_name, FileMode.Open, FileAccess.Read);
            StreamReader stream_reader = new StreamReader(ref_data_soure, Encoding.UTF8);
            List<string> lines = new List<string>();
            string line;
            int line_count = 0;
            while((line = stream_reader.ReadLine()) != null) //.ToList() .ToArray();
            {
                Console.WriteLine(line);
                line_count++;
                lines.Add(line);
            }
            stream_reader.Close();
            Console.WriteLine(line_count + " lines has been read. Data: " + lines[line_count-1]);
            Console.Write("Press any key to contine...");
            Console.Read();
        }
    }
}
