﻿using System;
namespace RandomBGColors
{
    internal class RandomBGColors
    {
        static void Main(string[] args)
        {
            //Set background color of the text to Blue
            Console.ForegroundColor = ConsoleColor.Cyan;
            //Generated a random number
            Random o_random = new Random();
            int random_num = o_random.Next(1, 25);
            Console.WriteLine("Random no gen 1 to 25 is: " + random_num);
            //Set background color of the text to Red
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Press any key to Continue...");
            Console.ReadLine();

        }
    }
}
