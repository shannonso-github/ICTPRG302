﻿using System;
using System.ComponentModel;

namespace PRateYTD {
    internal class Program {
        static void Main(string[] args)
        {
            // initialize variables
            double pay_rate; double no_of_hours_worked;
            double weekly_pay; int weeks_in_year = 52; double yearly_salary;
            // Dispaly Application title
            Console.WriteLine("Calculate YTD Salary From pay rate");
            // Display 2 underlines under title
            Console.WriteLine("====================================");
            // Try and Prompt user to enter pay rate
            try
            {
                Console.Write("Enter your pay rate: ");
                // read pay rate
                pay_rate = (double)Convert.ToDouble(Console.ReadLine());
            }
            // catch if any exceptions
            catch (Exception e) { throw; }
            // try and prompt user to enter no of hours worked
            try
            {
                Console.Write("Enter no of Hours worked: ");
                // read the no of hourse worked in a year
                no_of_hours_worked = (double)Convert.ToDouble(Console.ReadLine());
            }
            catch (Exception e) { throw; }
            //catch if any exceptions
            // Calculate weekly was as pay rate times no of hours worked.
            weekly_pay = pay_rate * no_of_hours_worked;
            // Calculate YTD Salary equal weeks in a year times weekly pay
            yearly_salary = weeks_in_year * weekly_pay;
            // Display to user YTD Salary with 2 decimal places.
            Console.WriteLine("Your YTD Salary:" + Math.Round(yearly_salary, 2));
            // Dispaly press any key to continue
            Console.WriteLine("Press any Key...");
            // Read in any key.
            Console.ReadLine();
        }
    }
}
