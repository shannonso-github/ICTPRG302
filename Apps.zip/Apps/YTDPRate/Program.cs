﻿using System;

namespace YTDPRate {
    internal class Program {
        static void Main(string[] args)
        {
            int yearly_salary; int weeks_in_year = 52;
            double no_of_hours_worked; double weekly_pay;
            double pay_rate;
            Console.WriteLine("Calculate hourly rate from YTD Salary");
            Console.WriteLine("====================================");
            try {
                Console.Write("Enter yearly Salary: ");
                yearly_salary = (int) Convert.ToDouble(Console.ReadLine());
            }catch (Exception e) { throw; }
            try {
                Console.Write("Enter no of Hours worked: ");
                no_of_hours_worked = (double)Convert.ToDouble(Console.ReadLine());
            }
            catch (Exception e) { throw; }
            weekly_pay = yearly_salary / weeks_in_year;
            pay_rate = weekly_pay / no_of_hours_worked;
            Console.WriteLine("Pay Rate for Employee is:" + Math.Round(pay_rate, 2));
            Console.WriteLine("Press any Key...");
            Console.ReadLine();
        }
    }
}
