﻿using System;
namespace ForLoopInputArray {
    internal class ForLoopInputArray {
        static void Main(string[] args) {
            // Store values in an array and print the value out
            // declare an arry of ints to store 8 elements.
            int[] lotto_nos = new int[7];
            for(int i = 0; i < lotto_nos.Length; i++)
            {
                // assign a number into the lotto_nos array
                lotto_nos[i] = i;
            }
            Console.WriteLine("Elements in Array:");
            // print an array of data value
            Console.Write("lotto_nos = [");
            for (int i = 0; i < lotto_nos.Length; i++)
            {
                //print out each eleemnt in the lotto_nos array
                Console.Write(lotto_nos[i] + ",");
            }
            Console.Write("\b] \n");
            Console.WriteLine();
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
    }
}
