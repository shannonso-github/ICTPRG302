﻿using System;
namespace ForLoop1 {
    internal class ForLoop1 {
        static void Main(string[] args) {
            Console.WriteLine("For loop 1 \n");
            Console.WriteLine("for(int i = 0; i < 5; i++)");
            Console.WriteLine("{");
            Console.WriteLine("    Console.WriteLine(i);");
            Console.WriteLine("}\nResult:");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("\n For loop 2 \n");
            Console.WriteLine("for (int i = 1; i <= 10; i = i + 1)");
            Console.WriteLine("{");
            Console.WriteLine("    Console.WriteLine(i);");
            Console.WriteLine("}\nResult:");
            for (int i=1; i <=10; i = i+1)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("Press any Key to Continue... ");
            Console.ReadLine();
        }
    }
}
