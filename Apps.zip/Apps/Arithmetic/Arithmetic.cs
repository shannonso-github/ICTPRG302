﻿
using System;
namespace Arithmetic
{
    class Arithmetic
    {
        static void Main(string[] args)
        {
            int a = 2, b = 3, x = 0; // initilise variables
            Console.WriteLine("a = 2, b = 3, x = 0");
            x = a + b; // addition operator
            Console.WriteLine(" a + b = " + x);
            x = a - b; // subtraction operator
            Console.WriteLine(" a - b = " + x);
            x = a / b; // division operator
            Console.WriteLine(" a / b = " + x);
            x = a % b; // modulus operator
            Console.WriteLine(" a % b = " + x);
            a++;
            Console.WriteLine(" a++ = " + a);
            a--;
            Console.WriteLine(" a-- = " + a);
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
    }
}
