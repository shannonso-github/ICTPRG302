﻿using System;

namespace HelloWorld
{
    class Helloworld
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
        }
    }
}
