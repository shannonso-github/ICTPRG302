﻿
using System;
namespace Comparison
{
    class Comparison
    {
        static void Main(string[] args)
        {
            int a = 2, b = 3, x = 0; // initialize variables
            Console.WriteLine("a = 2, b = 3, x = 0");
            if (a==b)
            {
                Console.WriteLine(" a == b");
            }
            else
            {
                Console.WriteLine("a does not equal b");
            }
            if(a != b) { Console.WriteLine("a does not equal b");  }
            if (a > b) { Console.WriteLine("a is greater than b"); } 
                else { Console.WriteLine("a is not greater than b"); }
            if (a < b) { Console.WriteLine("a is less than b"); } 
                else { Console.WriteLine("a is not less than b"); }
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
    }
}
