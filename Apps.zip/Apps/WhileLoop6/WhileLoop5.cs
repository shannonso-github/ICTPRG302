﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhileLoop5
{
    internal class WhileLoop5
    {
        public static int[] lotto_nos = new int[5];
        public static bool status = false;
        public static int index_no = 0;
        public static int a_number = 0;
        static void Main(string[] args)
        {
            /*int[] lotto_nos = new int[5];
            bool status = false;
            int index_no = 0;
            int a_number = 0; */
            Console.WriteLine("Enter 5 Lotto Nos:");
            /*    while(!status) // status false do, when true then exit
                {
                    Console.WriteLine("Status: " + status + " index no " + index_no);
                    while((a_number < 1) || (a_number > 35))
                    {
                        Console.WriteLine("Enter number " + index_no + " value: ");
                        a_number = Convert.ToInt32(Console.ReadLine());
                    }
                    lotto_nos[index_no] = a_number;
                    index_no++;
                    a_number = 0;
                    if (index_no == 5) { status = true; }
                    //status = true;
                } */
            GetUserNos(lotto_nos);
            Console.WriteLine("Status: " + status + " index no " + index_no);
            PrintArrayData(lotto_nos);
            Console.WriteLine();
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
        public static void GetUserNos(int[] lotto_nos)
        {
            while (!status) // status false do, when true then exit
            {
                Console.WriteLine("Status: " + status + " index no " + index_no);
                while ((a_number < 1) || (a_number > 35))
                {
                    Console.WriteLine("Enter number " + index_no + " value: ");
                    a_number = Convert.ToInt32(Console.ReadLine());
                }
                lotto_nos[index_no] = a_number;
                index_no++;
                a_number = 0;
                if (index_no == 5) { status = true; }
                //status = true;
            }
        }
        public static void PrintArrayData(int[] lotto_nos)
        {
            Console.Write("Lotto No: [");
            for(int i = 0; i < lotto_nos.Length; i++)
            {
                Console.Write(lotto_nos[i] + ",");
            }
            Console.Write("\b]");
        }
    }
}
