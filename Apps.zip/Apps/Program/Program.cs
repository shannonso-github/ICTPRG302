﻿using System;

namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {
            string app_title = "* DATATYPE EXAMPLE * ";
            Console.WriteLine(app_title);
            Console.WriteLine();
            int e = 12; // data type is an int and variable name is e, set to the no 12
            Console.WriteLine("Type of " + typeof(int) + " Min " + int.MinValue + " Max " + int.MaxValue);
            Console.WriteLine("Type of " + typeof(long) + " Min " + long.MinValue + " Max " + long.MaxValue);
            Console.WriteLine("Type of " + typeof(float) + " Min " + float.MinValue + " Max " + float.MaxValue);
            Console.WriteLine("Type of " + typeof(double) + " Min " + double.MinValue + " Max " + double.MaxValue);

            Console.WriteLine("Type of " + typeof(char) + " Min " + char.MinValue + " Max " + char.MaxValue);

            Console.WriteLine();
            Console.WriteLine("Press any key to Continue...");
            Console.ReadLine();
        }
    }
}
