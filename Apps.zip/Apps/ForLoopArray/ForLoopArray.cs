﻿using System;
namespace ForLoopArray {
    internal class ForLoopArray {
        static void Main(string[] args) {
            // for loop example for reading numbers in an array
            int[] lotto_nos = { 23, 11, 34, 6, 29, 16, 4 };
            Console.WriteLine("For earch array Example.1");
            foreach(int i in lotto_nos)
            {
                Console.Write(i + ",");
            }
            Console.WriteLine();
            Console.WriteLine();
            int[] lotto_no = { 2, 1, 27, 16, 30, 11, 9 };
            Console.Write("Array no 2 example = [");
            for(int i = 0; i < lotto_no.Length; i++)
            {
                Console.Write(lotto_no[i] + ",");
            }
            Console.Write("\b]\n");
            Console.WriteLine("Press any Key to Continue... ");
            Console.ReadLine();
        }
    }
}
