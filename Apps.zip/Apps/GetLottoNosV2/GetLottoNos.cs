﻿using System;
using System.CodeDom.Compiler;

namespace GetLottoNos {
    class GetLottoNos {
        public static int[] lotto_no = new int[5];
        public static int index_no = 0;
        static void Main(string[] args) {
            //Console.WriteLine("index+_no " + index_no);
            Console.WriteLine("Choose your 5 lotto no play: ");
            do
            {
                GetLottoNosInputv2();
                Console.WriteLine("index+_no " + index_no);
            } while (index_no < 5);
            PringArray(lotto_no);
            GetAnyKeyPress();
        }

        static void GetLottoNosInputv2()
        {
            int user_input_no = 0;
            string temp;
            // condition to check if user entera no  1 - 35
            while((user_input_no < 1) || (user_input_no > 35))
            {
                // Prompt user to enter a number 1 - 35
                Console.Write("Enter lotto no "); //+ (index_no + 1) + " must be between 1 and 35: ");
                // read number
                //  temp = Console.ReadLine();
                //  user_input_no = (int)Convert.ToUInt32((temp));
                //user_input_no = Int32.Parse(Console.ReadLine());
                user_input_no = Convert.ToInt32(Console.Read()); 
            }
            // assign user read no to array
            lotto_no[index_no] = user_input_no;
            // reset while loop condition, for user inp9ut
            
            //Console.Clear();
            user_input_no = 0;
            index_no++;

        }

        public static void GetLottoNosInput()
        {
            int user_input = -1;
            Console.WriteLine("Choose your 5 lotto no play: ");
            // repeat task to enter 5 eleemnts into array
           // for(int i = 0; i < lotto_no.Length; i++) {
                // condition to check if user entera no  1 - 35
                while(user_input < 1 && user_input > 35)
                {
                    // Prompt user to enter a number 1 - 35
                    Console.Write("Enter lotto no " + index_no+1 + " must be between 1 and 35: ");
                    // read number
                    user_input = Convert.ToInt32(Console.ReadLine());
                }
                // assign user read no to array
                lotto_no[index_no] = user_input;
            // reset while loop condition, for user inp9ut
                index_no++;
                //user_input = -1;
           // }

        }
        static void GetAnyKeyPress() {
            Console.WriteLine("Press any key to Continue... ");
            Console.ReadLine();
        }

        static void PringArray(int[] array)
        {
            Console.Write("Array: [");
            for(int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i] + ",");
            }
            Console.Write("\b]\n");
        }

    }
}
