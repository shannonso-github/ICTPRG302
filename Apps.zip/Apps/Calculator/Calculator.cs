﻿using System;
namespace Calculator {
    class Calculator {
        static private double x = 0;
        static private double result = 0;
        static void Main(string[] args) {
            //char op; // var to store user operation
            int a; int b; // variable to store numbers
            string op; // var to store user operation
            // program Heading
            Console.WriteLine("********** **********  **********");
            Console.WriteLine("******  CALCULATOR PROGRAM  *****");
            Console.WriteLine("********** **********  **********");
            Console.WriteLine();
            //Get User Calculator Operation
            //Display User Message to input caculator operation
            Console.WriteLine("presss + _ / * on the keyboard");
            // Note readline reads string need Convert.ToChar
            op = Console.ReadLine();
            // Get User Number
            Console.WriteLine("Enter Fisrt number to Calculate ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Second number to Calculate ");
            b = Convert.ToInt32(Console.ReadLine());
            // Calculate Answer and Display Answer
            result = Caculator(op, a, b);
            Console.WriteLine("Ans is: " + result);
            // end of key press
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }

        static double Caculator(string op, int num1, int num2) 
        {            
            switch(op)
            {
                case "+":
                    x = num1 + num2;
                    break;
                case "-":
                    x = num1 - num2;
                    break;
                case "*":
                    x = num1 * num2;
                    break;
                case "/":
                    x = num1 / num2;
                    break;
                default:
                    break;
            }
            return x;
        }
    }
}
