﻿using System;
namespace GetLastName {
    class GetLastName {
        static void Main(string[] args) {
            string full_name = "";
            Console.Write("Type your First name Last Name: "); 
            // Read what user enters on command line
            full_name = Console.ReadLine();
            // Location of the letter " "
            int char_pos = full_name.IndexOf(" ") + 1;
            // Get Last Name
            string last_name = full_name.Substring(char_pos);
            // Print result
            Console.Write("Last Name is: " + last_name);
            Console.Write("\nPress any key to continue...");
            Console.ReadLine();
        }
    }
}
