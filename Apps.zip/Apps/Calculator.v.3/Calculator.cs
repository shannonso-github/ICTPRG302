﻿using System;
namespace Calculator {
    class Calculator {
        static public string op;
        static void Main(string[] args) {
            //char op; // var to store user operation
            double result = 0; int a; int b; // variable to store numbers
            //string op; // var to store user operation
            program_heading();
            op = get_user_operation();
            a = get_user_input("Enter number: ");
            b = get_user_input("Enter number: ");
            // Calculate Answer and Display Answer
            result = Caculator(op, a, b);
            Console.WriteLine("Ans is: " + result);
            end_of_key_press();
        }

        static double Caculator(string op, int num1, int num2) {
            double x = 0;
            switch(op)
            {
                case "+":
                    x = num1 + num2;
                    break;
                case "-":
                    x = num1 - num2;
                    break;
                case "*":
                    x = num1 * num2;
                    break;
                case "/":
                    x = num1 / num2;
                    break;
                default:
                    break;
            }
            return x;
        }
        static void program_heading()
        {
            Console.WriteLine("********** **********  **********");
            Console.WriteLine("******  CALCULATOR PROGRAM  *****");
            Console.WriteLine("********** **********  **********");
            Console.WriteLine();
        }
        static string get_user_operation()
        {
            //Get User Calculator Operation
            //Display User Message to input caculator operation
            Console.WriteLine("presss + _ / * on the keyboard");
            // Note readline reads string need Convert.ToChar
            op = Console.ReadLine();
            return op;
        }
        static int get_user_input(string user_message)
        {
            int a_number;
            // Get User Number
            Console.WriteLine(user_message);
            a_number = Convert.ToInt32(Console.ReadLine());
            return a_number;
        }
        static void end_of_key_press()
        {
            // end of key press
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
    }
}
