﻿using System;
namespace GradeCode {
    internal class GradeCode {
        static void Main(string[] args)
        {
            double score = -1;
            Console.Write("Enter scroe mark: ");
            score = Convert.ToDouble(Console.ReadLine());
            if (score < 0 || score > 100) { Console.WriteLine("Score out of range!"); }
            else if (score >= 0 && score < 50) { Console.WriteLine("Fail"); }
            else if (score >= 50 && score < 60) { Console.WriteLine("Grade D"); }
            else if (score >= 60 && score < 70) { Console.WriteLine("Grade C"); }
            else if (score >= 70 && score < 80) { Console.WriteLine("Grade B"); }
            else if (score >= 80 && score < 90) { Console.WriteLine("Grade A"); }
            else if (score >= 90 && score <= 100) { Console.WriteLine("Grade A+"); }
            Console.WriteLine("Press any key to continue..."); Console.ReadLine();
        }
    }
}
